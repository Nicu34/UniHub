use phpdatabase

create table Categories(
	id int not null,
    name varchar(20),
    primary key(id)
)

create table Items(
	id int not null,
    name varchar(20),
    categoryID int,
	primary key(id),
    foreign key(categoryID) references Categories(id)
)


insert into Categories (id, name) values (1, "rock")
insert into Categories (id, name) values (2, "rock2")
insert into Categories (id, name) values (3, "rock3")
insert into Categories (id, name) values (4, "rock4")
insert into Categories (id, name) values (5, "rock5")

select * from Categories


insert into Items (id, name, categoryID) values(1, "powerPlant1", 1)
insert into Items (id, name, categoryID) values(2, "powerPlant2", 2)
insert into Items (id, name, categoryID) values(3, "powerPlant3", 2)
insert into Items (id, name, categoryID) values(4, "powerPlant4", 5)
insert into Items (id, name, categoryID) values(5, "powerPlant5", 4)
insert into Items (id, name, categoryID) values(6, "powerPlant6", 2)
insert into Items (id, name, categoryID) values(7, "powerPlant7", 2)
insert into Items (id, name, categoryID) values(8, "powerPlant8", 2)


select Items.id, Items.name, Categories.name from Items inner join Categories on Items.categoryID = Categories.ID where categoryID = 2